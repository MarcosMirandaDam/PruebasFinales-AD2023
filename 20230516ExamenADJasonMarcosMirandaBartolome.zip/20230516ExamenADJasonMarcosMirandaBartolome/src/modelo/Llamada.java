
package modelo;

/**
 *
 * @author Marcos Miranda
 */


public class Llamada {
    
    private int idLlamada;
    private int numeroTelefonoDestino;
    private String fecha;
    private float duracion;
    private float coste;

    public Llamada() {
    }

    public Llamada(int idLlamada, int numeroTelefonoDestino, String fecha, float duracion, float coste) {
        this.idLlamada = idLlamada;
        this.numeroTelefonoDestino = numeroTelefonoDestino;
        this.fecha = fecha;
        this.duracion = duracion;
        this.coste = coste;
    }

    public int getIdLlamada() {
        return idLlamada;
    }

    public void setIdLlamada(int idLlamada) {
        this.idLlamada = idLlamada;
    }

    public int getNumeroTelefonoDestino() {
        return numeroTelefonoDestino;
    }

    public void setNumeroTelefonoDestino(int numeroTelefonoDestino) {
        this.numeroTelefonoDestino = numeroTelefonoDestino;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public float getDuracion() {
        return duracion;
    }

    public void setDuracion(float duracion) {
        this.duracion = duracion;
    }

    public float getCoste() {
        return coste;
    }

    public void setCoste(float coste) {
        this.coste = coste;
    }

    @Override
    public String toString() {
        return "llamada{" + "idLlamada=" + idLlamada + ", numeroTelefonoDestino=" + numeroTelefonoDestino + ", fecha=" + fecha + ", duracion=" + duracion + ", coste=" + coste + '}';
    }
    
    
    
}
