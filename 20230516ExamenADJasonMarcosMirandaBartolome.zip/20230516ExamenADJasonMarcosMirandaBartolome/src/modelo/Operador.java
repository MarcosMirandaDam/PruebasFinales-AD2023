package modelo;

import java.util.List;

/**
 *
 * @author Marcos Miranda
 */
public class Operador {
    
    private int idOperador;
    private String nombre;
    private String pais;
    private List<Sim> listaTarjetasSim;

    public Operador() {
    }

    public Operador(int idOperador, String nombre, String pais, List<Sim> listaTarjetasSim) {
        this.idOperador = idOperador;
        this.nombre = nombre;
        this.pais = pais;
        this.listaTarjetasSim = listaTarjetasSim;
    }

    public int getIdOperador() {
        return idOperador;
    }

    public void setIdOperador(int idOperador) {
        this.idOperador = idOperador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public List<Sim> getListaTarjetasSim() {
        return listaTarjetasSim;
    }

    public void setListaTarjetasSim(List<Sim> listaTarjetasSim) {
        this.listaTarjetasSim = listaTarjetasSim;
    }

    @Override
    public String toString() {
        return "Operador{" + "idOperador=" + idOperador + ", nombre=" + nombre + ", pais=" + pais + ", listaTarjetasSim=" + listaTarjetasSim + '}';
    }
    
    
}
