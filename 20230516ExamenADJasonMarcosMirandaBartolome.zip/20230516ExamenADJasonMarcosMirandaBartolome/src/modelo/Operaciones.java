package modelo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

/**
 *
 * @author Marcos Miranda
 */
public class Operaciones {
    
    /**
     * metodo que crea un jsonObject tipo llamada
     * @param llamada
     * @return 
     */
    public JsonObject crearLlamada(Llamada llamada){
         JsonObject llamadaJson = Json.createObjectBuilder()
                .add("idLlamada", llamada.getIdLlamada())
                .add("numeroTelefonoDestino", llamada.getNumeroTelefonoDestino())
                .add("fecha", llamada.getFecha())
                .add("duracion", llamada.getDuracion())
                .add("coste", llamada.getCoste())
                .build();
        return llamadaJson;
        
    }
     
    /**
     * creamo json array de llamadas
     * @param llamadas
     * @return 
     */
    private JsonArray JsonArrayLlamadas(List<Llamada> llamadas){
        JsonArrayBuilder JsonArrayLlamadas = Json.createArrayBuilder();
        for (Llamada llamada : llamadas) {
            JsonArrayLlamadas.add(crearLlamada(llamada));
        }
        return JsonArrayLlamadas.build();
    }
    
    public JsonObject crearSim(Sim sim){
        JsonObject jsonSim = Json.createObjectBuilder()
                .add("idSim", sim.getIdSim())
                .add("imei", sim.getImei())
                .add("numeroTelefono", sim.getNumeroTelefono())
                .add("llamadas", JsonArrayLlamadas(sim.getLlamadas()))
                .build();
        return jsonSim;
    }
    
    /**
     * jsonArray de sims
     * @param listaTarjetas
     * @return 
     */
    private JsonArray JsonArraySims(List<Sim> listaTarjetas){
        JsonArrayBuilder JsonArraySims = Json.createArrayBuilder();
        for (Sim sim : listaTarjetas) {
            JsonArraySims.add(crearSim(sim));
        }
        return JsonArraySims.build();
    }
    
    public JsonObject crearOperador(Operador operador){
        JsonObject jsonOperador = Json.createObjectBuilder()
                .add("idOperador", operador.getIdOperador())
                .add("nombre", operador.getNombre())
                .add("pais", operador.getPais())
                .add("sim", JsonArraySims(operador.getListaTarjetasSim()))
                .build();
        return jsonOperador;
    }
    
    /**
     * json array de operadores
     * @param listaOperadores
     * @return 
     */
    public JsonArray crearJsonArrayOperador(List<Operador>listaOperadores){
        JsonArrayBuilder jsonArrayOperadores = Json.createArrayBuilder();
        for (Operador operador : listaOperadores) {
            jsonArrayOperadores.add(crearOperador(operador));
        }
        return jsonArrayOperadores.build();
    }
    
    /**
     * metodo que crea el archivo json
     * @param jsonObject
     * @param nombreArchivoSalida
     * @return
     * @throws IOException 
     */
    public boolean escribirArchivoJson(JsonObject jsonObject, String nombreArchivoSalida) throws IOException {
        boolean creadoActualizado = false;
        FileWriter ficheroSalida = new FileWriter(nombreArchivoSalida);
        JsonWriter jsonWriter = Json.createWriter(ficheroSalida);
        jsonWriter.writeObject(jsonObject);                                     //escribimos el objeto completo
        ficheroSalida.flush();
        ficheroSalida.close();

        creadoActualizado = false;
        return creadoActualizado;
    }
    
    /**
     * coste total de las llamadas de un operador
     * @param nombreOperador
     * @return
     * @throws FileNotFoundException 
     */
    public float costeTotalLlamadasOperador(String nombreOperador) throws FileNotFoundException{
        float costeTotal=0.0f;
        FileReader entrada = new FileReader("jsonSalidaTelefonia.json");
        JsonReader jsonReader = Json.createReader(entrada);
        JsonArray readArray = jsonReader.readArray();                                       // objeto reader , para leer el array
        for (int i = 0; i < readArray.size(); i++) {
            JsonNumber coste = readArray.getJsonObject(i).getJsonNumber("coste");
            costeTotal += coste.doubleValue();
        }
        return costeTotal;
            
            
}
    
}
