
package modelo;

import java.util.List;

/**
 *
 * @author Marcos Miranda
 */
public class Sim {
    
    private int idSim;
    private String imei;
    private int numeroTelefono;
    private List<Llamada> llamadas;

    public Sim() {
    }

    public Sim(int idSim, String imei, int numeroTelefono, List<Llamada> llamadas) {
        this.idSim = idSim;
        this.imei = imei;
        this.numeroTelefono = numeroTelefono;
        this.llamadas = llamadas;
    }

    public int getIdSim() {
        return idSim;
    }

    public void setIdSim(int idSim) {
        this.idSim = idSim;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public int getNumeroTelefono() {
        return numeroTelefono;
    }

    public void setNumeroTelefono(int numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }

    public List<Llamada> getLlamadas() {
        return llamadas;
    }

    public void setLlamadas(List<Llamada> llamadas) {
        this.llamadas = llamadas;
    }

    @Override
    public String toString() {
        return "sim{" + "idSim=" + idSim + ", imei=" + imei + ", numeroTelefono=" + numeroTelefono + ", llamadas=" + llamadas + '}';
    }
    
    
    
}
