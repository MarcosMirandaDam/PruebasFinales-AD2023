
package excepciones;

/**
 *
 * @author sssoc
 */
public class pendientePonerNombre extends Exception{

    public pendientePonerNombre() {
    }

    public pendientePonerNombre(String mensajeError) {
        super(mensajeError);
    }

    @Override
    public String getMessage() {
        String mensaje="No se puede borrar el ejercicio, existe en otros programas.";
        return mensaje; 
    }
    
    
}
