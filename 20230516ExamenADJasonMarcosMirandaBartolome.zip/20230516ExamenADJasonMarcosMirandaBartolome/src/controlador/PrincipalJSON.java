package controlador;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import modelo.Llamada;
import modelo.Operaciones;
import modelo.Operador;
import modelo.Sim;

/**
 *
 * @author Marcos Miranda
 */
public class PrincipalJSON {

    public static void main(String[] args) throws IOException {
       
       Operaciones operador=new Operaciones();
       
       //creo llamada
       Llamada llamada1=new Llamada();
       llamada1.setIdLlamada(1);
       llamada1.setNumeroTelefonoDestino(1231345);
       llamada1.setFecha("16/05/2023");
       llamada1.setDuracion(2.40f);
       llamada1.setCoste(1.87f);
       
       //la añado a una lista de llamadas 
       List<Llamada> llamadas=new ArrayList<>();
       llamadas.add(llamada1);
       
       //creamos el jsonObject de llamada
       JsonObject crearLlamada1 = operador.crearLlamada(llamada1);
       
       // creamos una sim
       Sim sim1=new Sim();
       sim1.setIdSim(1);
       sim1.setImei("65465465465");
       sim1.setNumeroTelefono(636146896);
       sim1.setLlamadas(llamadas);
       
       //creamos la lista de SIMs
       List<Sim> listaTarjetasSim=new ArrayList<>();
       listaTarjetasSim.add(sim1);
       
        //creamos jsonObject de sim
        JsonObject crearSim = operador.crearSim(sim1);
        
        //creamos un operador
        Operador operador1=new Operador();
        operador1.setIdOperador(1);
        operador1.setNombre("Movistar");
        operador1.setPais("Asturias");
        operador1.setListaTarjetasSim(listaTarjetasSim);
        
        //creamos el object de operador
        JsonObject crearOperador = operador.crearOperador(operador1);
        
        
        //creamos una lista de operadores
        List<Operador>listaOperadores=new ArrayList<>();
        listaOperadores.add(operador1);
        JsonArray JsonArrayOperador = operador.crearJsonArrayOperador(listaOperadores);
        
         
       
        
        //creamos archivo json
        operador.escribirArchivoJson(crearOperador, "jsonSalidaTelefonia.json");
       
        
            
            
            
            
            
            
            
            
            
            
            
            
            
          
            
    }
    
}
    

