package org.swing.examenadmarcosmirandabartolome;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Marcos Miranda
 */
public class GestoraAppExamenAD {

    /**
     * metodo que establece la conexión a la base de datos creada en workbench
     * CancionesAutores
     *
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    private Connection conexionBD() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String cadenaConexion = "jdbc:mysql://localhost:3306/telefonia?user=root&password=pruebas";
        Connection conexionBD = DriverManager.getConnection(cadenaConexion);

        return conexionBD;

    }

    /**
     * metodo que agrupa los resultados para mostrar
     *
     * @param resultSet
     * @throws SQLException
     */
    public void mostrarResultSet(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();                   // cogemos los metaDatos
        int numeroColumnasMostrar = metaData.getColumnCount();                  //numero de columnas de esos metadatos

        while (resultSet.next()) {
            for (int i = 1; i <= numeroColumnasMostrar; i++) {
                String valorColumna = resultSet.getString(i);
                System.out.println(valorColumna + " | ");
            }
            System.out.println("");

        }
    }

    /**
     * metodo suma duracion llamadas de una sim en una fecha
     *
     * @param id_simOrigen
     * @param fecha
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public ResultSet retornarTotalLlamadasIdSimPorFecha(String id_simOrigen, String fecha) throws ClassNotFoundException, SQLException {
        Connection conexionBd = this.conexionBD();                    //instanciamos la conexion a la bbdd
        Statement statement = conexionBd.createStatement();           //instancia retorna sentencia normal
        PreparedStatement psLlamadasSim = conexionBd.prepareCall("SELECT sum(duracion)\n"
                + "from llamada\n"
                + "where id_simOrigen=? AND fecha=?");                           //declaramos el preparedStatement
        psLlamadasSim.setString(1, fecha); 
        System.out.println(psLlamadasSim.toString());//damos formato
        ResultSet llamadasSim = psLlamadasSim.executeQuery();                    // el resultSet es la ejecucion del prepared statement
        return llamadasSim;
    }

    /**
     * metodo que devuelve el numero total de llamdas de una id_simOrigen
     *
     * @param nombre
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public ResultSet retornarTotalLlamadasSim(String id_simOrigen) throws ClassNotFoundException, SQLException {
        Connection conexionBd = this.conexionBD();                    //instanciamos la conexion a la bbdd
        Statement statement = conexionBd.createStatement();           //instancia retorna sentencia normal
        PreparedStatement psLlamadasSim = conexionBd.prepareCall("SELECT count(idllamada)\n"
                + "from llamada\n"
                + "where id_simOrigen=?");    //declaramos el preparedStatement
        psLlamadasSim.setString(1, id_simOrigen);                                         //damos formato
        ResultSet llamadasSim = psLlamadasSim.executeQuery();                    // el resultSet es la ejecucion del prepared statement
        return llamadasSim;
    }

    /**
     * coste total de las llamadas por operador
     *
     * @param nombre
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public ResultSet retornarTotalLlamadasOperador(String nombre) throws ClassNotFoundException, SQLException {
        Connection conexionBd = this.conexionBD();                    //instanciamos la conexion a la bbdd
        Statement statement = conexionBd.createStatement();           //instancia retorna sentencia normal
        PreparedStatement psLlamadasOperador = conexionBd.prepareCall("SELECT sum(coste)\n"
                + "from llamada\n"
                + "INNER JOIN operador ON idoperador=sim_operador_idoperador\n"
                + "WHERE nombre=?");    //declaramos el preparedStatement
        psLlamadasOperador.setString(1, nombre);                                         //damos formato
        ResultSet llamadasOperador = psLlamadasOperador.executeQuery();                    // el resultSet es la ejecucion del prepared statement
        return llamadasOperador;
    }

    /**
     * metodo que devuelve la llamada con mas duracion
     *
     * @param String
     * @param id_simOrigen
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public ResultSet retornarLlamadaMaxDuracion(String String, String id_simOrigen) throws ClassNotFoundException, SQLException {
        Connection conexionBd = this.conexionBD();                    //instanciamos la conexion a la bbdd
        Statement statement = conexionBd.createStatement();           //instancia retorna sentencia normal
        PreparedStatement psllamadasMaxDuracion = conexionBd.prepareCall("SELECT idllamada\n"
                + "from llamada\n"
                + "WHERE duracion AND id_simOrigen=?\n"
                + "ORDER BY duracion");    //declaramos el preparedStatement
        psllamadasMaxDuracion.setString(1, id_simOrigen);                                         //damos formato
        ResultSet llamadaMaxDuracion = psllamadasMaxDuracion.executeQuery();                    // el resultSet es la ejecucion del prepared statement
        return llamadaMaxDuracion;
    }

    /**
     * metodo que retorna el operador con mas llamdas
     *
     * @param String
     * @param id_simOrigen
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public ResultSet retornarOperadorMasLlamadas() throws ClassNotFoundException, SQLException {
        Connection conexionBd = this.conexionBD();                    //instanciamos la conexion a la bbdd
        Statement statement = conexionBd.createStatement();           //instancia retorna sentencia normal
        PreparedStatement psllamadasMaxDuracion = conexionBd.prepareCall("SELECT nombre, count(idllamada)\n"
                + "from operador\n"
                + "inner join llamada on sim_operador_idoperador=idoperador\n"
                + "group by nombre");    //declaramos el preparedStatement
        //damos formato
        ResultSet llamadaMaxDuracion = psllamadasMaxDuracion.executeQuery();                    // el resultSet es la ejecucion del prepared statement
        return llamadaMaxDuracion;
    }

}
