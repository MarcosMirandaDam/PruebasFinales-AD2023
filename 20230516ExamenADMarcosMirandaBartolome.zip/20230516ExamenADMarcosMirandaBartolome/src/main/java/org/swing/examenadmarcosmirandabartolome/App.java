package org.swing.examenadmarcosmirandabartolome;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Marcos Miranda
 */
public class App {

    public static void main(String[] args) {

        try {
            GestoraAppExamenAD siri = new GestoraAppExamenAD();
            
            //llamadas de una sim determinada por su id y fecha determinada
            String id_simOrigen="654654";
            String fecha="1998-09-12";
            ResultSet totalLlamadasFecha = siri.retornarTotalLlamadasIdSimPorFecha(id_simOrigen, fecha);
            System.out.println("*****MOSTRANDO LLAMADAS SIM POR FECHA*****");
            siri.mostrarResultSet(totalLlamadasFecha);

            //llamadas de una sim determinada por su id
            ResultSet totalLlamadas = siri.retornarTotalLlamadasSim(id_simOrigen);
            System.out.println("*****MOSTRANDO LLAMADAS SIM*****");
            siri.mostrarResultSet(totalLlamadas);
            
            
            //llamadas por operador
            String operador="Vodafone";
            ResultSet totalCosteLlamadasOperador = siri.retornarTotalLlamadasOperador(operador);
            System.out.println("*****MOSTRANDO LLAMADAS OPERADOR DETERMINADO*****");
            siri.mostrarResultSet(totalCosteLlamadasOperador);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
